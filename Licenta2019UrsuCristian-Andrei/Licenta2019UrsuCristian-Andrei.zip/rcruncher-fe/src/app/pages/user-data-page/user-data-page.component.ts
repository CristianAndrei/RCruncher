import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-data-page',
  templateUrl: './user-data-page.component.html',
  styleUrls: ['./user-data-page.component.css']
})
export class UserDataPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
