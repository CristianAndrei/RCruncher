export interface BaseModel {

}