export * from './google-api-natural-language.service';
