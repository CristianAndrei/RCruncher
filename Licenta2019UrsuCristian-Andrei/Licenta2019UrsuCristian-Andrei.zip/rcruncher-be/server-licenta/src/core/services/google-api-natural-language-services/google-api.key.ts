export const NaturalLanguageGoogleApiSettings = {
    apiKey : 'AIzaSyAbdZ2_9o3EkDgeWjbwCr1KIUdlIGt7PaM',
};
