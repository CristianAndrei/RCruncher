export * from './kohonen-network';
export * from './kohonen.options';
