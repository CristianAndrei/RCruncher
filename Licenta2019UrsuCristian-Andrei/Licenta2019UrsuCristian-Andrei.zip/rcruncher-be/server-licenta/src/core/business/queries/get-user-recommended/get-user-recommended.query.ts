export class GetUserRecommendedQuery {
    constructor(public readonly redditUserName: string) { }
}
