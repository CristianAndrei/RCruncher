export class GetTrainedUsersQuery {
}