export class GetTopicsForUserQuery {
    constructor(public readonly redditUserName: string) { }
}
