export class GetApplicationDataQuery {
    constructor() { }
}
