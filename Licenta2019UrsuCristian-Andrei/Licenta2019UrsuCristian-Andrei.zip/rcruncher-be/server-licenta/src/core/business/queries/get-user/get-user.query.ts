export class GetUserQuery {
    constructor(public readonly redditUserName: string) { }
}
