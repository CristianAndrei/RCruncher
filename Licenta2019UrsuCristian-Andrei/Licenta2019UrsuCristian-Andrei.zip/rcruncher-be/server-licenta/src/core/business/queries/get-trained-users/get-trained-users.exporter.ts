export * from './get-trained-users.handler';
export * from './get-trained-users.query';
