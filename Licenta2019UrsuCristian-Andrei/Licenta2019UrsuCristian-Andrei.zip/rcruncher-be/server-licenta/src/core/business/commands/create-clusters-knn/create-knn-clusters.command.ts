import { ICommand } from '@nestjs/cqrs';

export class CreateKnnClustersCommand implements ICommand {
  constructor() { }
}
