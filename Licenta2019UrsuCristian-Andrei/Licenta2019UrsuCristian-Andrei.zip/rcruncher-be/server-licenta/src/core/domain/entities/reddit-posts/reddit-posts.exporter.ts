export * from './reddit-post.entity';
export * from './google-natural-language-sentence.entity';
export * from './google-natural-language-object.entity';
export * from './google-natural-language-category.entity';