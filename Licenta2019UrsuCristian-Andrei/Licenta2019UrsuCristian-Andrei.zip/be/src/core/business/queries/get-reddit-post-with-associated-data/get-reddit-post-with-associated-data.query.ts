export class GetRedditPostWithAssociatedDataQuery {
    constructor(public readonly redditPostName: string) { };
}